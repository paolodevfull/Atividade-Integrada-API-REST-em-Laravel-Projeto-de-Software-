<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class User extends Model
{
    use HasFactory;

    protected $table = 'users';

    protected $fillable = [
        'nome',
        'email',
        'senha',
        'telefone',
        'tipo'
    ];

    protected $hidden = [
        'senha',
    ];
}