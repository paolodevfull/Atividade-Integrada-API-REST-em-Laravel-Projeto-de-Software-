<?php
require_once "conexao.php";

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    $cnpj = $_POST["cnpj"];
    $nome = $_POST["nome"];
    $localizacao = $_POST["localizacao"];
    $catalogo = $_POST["catalogo"];

    $sql = "INSERT INTO Loja 
            (CNPJ, Nome, Localizacao, Catalogo_Ferramentas)
            VALUES (:cnpj, :nome, :localizacao, :catalogo)";

    $stmt = $pdo->prepare($sql);

    $stmt->execute([
        ":cnpj" => $cnpj,
        ":nome" => $nome,
        ":localizacao" => $localizacao,
        ":catalogo" => $catalogo
    ]);

    echo "Loja cadastrada com sucesso!";
}
?>

<form method="POST">

    <label>CNPJ:</label>
    <input type="text" name="cnpj" required>

    <br><br>

    <label>Nome:</label>
    <input type="text" name="nome" required>

    <br><br>

    <label>Localização:</label>
    <input type="text" name="localizacao">

    <br><br>

    <label>Catálogo de Ferramentas:</label>
    <input type="text" name="catalogo">

    <br><br>

    <button type="submit">Cadastrar</button>

</form>