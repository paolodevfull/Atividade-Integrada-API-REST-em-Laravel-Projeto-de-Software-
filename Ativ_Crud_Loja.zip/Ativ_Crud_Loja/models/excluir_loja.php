<?php
require_once "conexao.php";

$id = $_GET["id"];

$sql = "DELETE FROM Loja WHERE ID = :id";

$stmt = $pdo->prepare($sql);

$stmt->execute([
    ":id" => $id
]);

echo "Loja excluída com sucesso!";

echo "<br><br>";

echo '<a href="listar_lojas.php">Voltar para lista</a>';
?>