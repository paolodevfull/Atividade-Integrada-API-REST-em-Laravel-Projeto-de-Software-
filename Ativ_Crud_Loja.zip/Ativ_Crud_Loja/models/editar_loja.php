<?php
require_once "conexao.php";

$id = $_GET["id"];

$sql = "SELECT * FROM Loja WHERE ID = :id";

$stmt = $pdo->prepare($sql);
$stmt->execute([":id" => $id]);

$loja = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$loja) {
    die("Loja não encontrada.");
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    $cnpj = $_POST["cnpj"];
    $nome = $_POST["nome"];
    $localizacao = $_POST["localizacao"];
    $catalogo = $_POST["catalogo"];

    $sql = "UPDATE Loja SET
            CNPJ = :cnpj,
            Nome = :nome,
            Localizacao = :localizacao,
            Catalogo_Ferramentas = :catalogo
            WHERE ID = :id";

    $stmt = $pdo->prepare($sql);

    $stmt->execute([
        ":cnpj" => $cnpj,
        ":nome" => $nome,
        ":localizacao" => $localizacao,
        ":catalogo" => $catalogo,
        ":id" => $id
    ]);

    echo "Loja atualizada com sucesso!";
}
?>

<h2>Editar Loja</h2>

<form method="POST">

    <label>CNPJ:</label>
    <input type="text" name="cnpj"
           value="<?= $loja["CNPJ"] ?>" required>

    <br><br>

    <label>Nome:</label>
    <input type="text" name="nome"
           value="<?= $loja["Nome"] ?>" required>

    <br><br>

    <label>Localização:</label>
    <input type="text" name="localizacao"
           value="<?= $loja["Localizacao"] ?>">

    <br><br>

    <label>Catálogo de Ferramentas:</label>
    <input type="text" name="catalogo"
           value="<?= $loja["Catalogo_Ferramentas"] ?>">

    <br><br>

    <button type="submit">Salvar Alterações</button>

</form>