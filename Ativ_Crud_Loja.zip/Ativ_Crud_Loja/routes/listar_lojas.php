<?php
require_once "conexao.php";

$sql = "SELECT * FROM Loja";
$stmt = $pdo->query($sql);

$lojas = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<h2>Lista de Lojas</h2>

<table border="1">

    <tr>
        <th>ID</th>
        <th>CNPJ</th>
        <th>Nome</th>
        <th>Localização</th>
        <th>Catálogo de Ferramentas</th>
        <th>Ações</th>
    </tr>

    <?php foreach ($lojas as $loja): ?>

    <tr>

        <td><?= $loja["ID"] ?></td>

        <td><?= $loja["CNPJ"] ?></td>

        <td><?= $loja["Nome"] ?></td>

        <td><?= $loja["Localizacao"] ?></td>

        <td><?= $loja["Catalogo_Ferramentas"] ?></td>

        <td>
            <a href="editar_loja.php?id=<?= $loja["ID"] ?>">
                Editar
            </a>

            |

            <a href="excluir_loja.php?id=<?= $loja["ID"] ?>">
                Excluir
            </a>
        </td>

    </tr>

    <?php endforeach; ?>

</table>