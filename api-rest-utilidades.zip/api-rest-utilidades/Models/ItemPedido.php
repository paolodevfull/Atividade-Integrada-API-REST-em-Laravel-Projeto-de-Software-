<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class ItemPedido extends Model
{
    protected $table = 'item_pedidos'; 
    protected $fillable = ['quantidade', 'valor_unitario', 'pedido_id', 'produto_id'];
}
