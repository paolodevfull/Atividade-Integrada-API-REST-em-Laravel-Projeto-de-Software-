<?php

use App\Http\Controllers\MusicApiController;
use App\Models\Music;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\ItemPedidoController;

Route::get('/user', function (Request $request) {
    return $request->user();
})->middleware('auth:sanctum');

Route::get('/hello', function (Request $request) {
    return "Olá mundo!";
});

Route::get('/musics', [MusicApiController::class, 'index'] );
Route::post('/musics', [MusicApiController::class, 'store'] );

Route::apiResource('itempedidos', ItemPedidoController::class);

Route::put('/musics/{id}', [MusicApiController::class, 'update'] );

Route::delete('/musics/{id}', [MusicApiController::class, 'destroy'] );
