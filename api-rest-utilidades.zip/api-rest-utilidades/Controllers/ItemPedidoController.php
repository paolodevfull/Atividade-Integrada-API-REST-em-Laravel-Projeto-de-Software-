<?php

namespace App\Http\Controllers;

use App\Models\ItemPedido;
use Illuminate\Http\Request;

class ItemPedidoController extends Controller {
    
    public function index() {
        return response()->json(ItemPedido::all(), 200);
    }

    public function store(Request $request) {
        $item = ItemPedido::create($request->all());
        return response()->json($item, 201);
    }

    public function show($id) {
        $item = ItemPedido::find($id);
        if(!$item) {
            return response()->json(['erro' => 'Item não encontrado'], 404);
        }
        return response()->json($item, 200);
    }

    public function update(Request $request, $id) {
        $item = ItemPedido::find($id);
        if(!$item) {
            return response()->json(['erro' => 'Item não encontrado'], 404);
        }
        $item->update($request->all());
        return response()->json($item, 200);
    }

    public function destroy($id) {
        $item = ItemPedido::find($id);
        if(!$item) {
            return response()->json(['erro' => 'Item não encontrado'], 404);
        }
        $item->delete();
        return response()->json(null, 204);
    }
}

